# Photography Business Tycoon — Android project (0.1.0)

A playable 2D, landscape-first management-game prototype. The current build includes local/offline gameplay and device-local saves.

## Included gameplay
- Company naming and headquarters
- Client enquiries and booking conversion
- Production projects and delivery/payment loop
- Team hiring and payroll
- Camera, lens, lighting, support, drone and audio equipment purchasing
- India-inspired city dispatch/travel loop
- Cash ledger, revenue, payroll and expenses
- Day progression, reputation and random incoming leads

## Run in a browser
Requires Node.js 18+:
```bash
npm install
npm run start
```
Open the Vite URL shown in the terminal.

## Build Android APK (requires Android Studio + Android SDK)
1. Install Android Studio (current stable) and Android SDK Platform/Build Tools.
2. In this folder:
```bash
npm install
npm run build
npx cap add android
npx cap sync android
npx cap open android
```
3. In Android Studio select **Build > Build Bundle(s) / APK(s) > Build APK(s)**.
4. The debug APK will be under `android/app/build/outputs/apk/debug/`.

The Android app is configured for landscape orientation in `android/app/src/main/AndroidManifest.xml` after `npx cap add android`; set the main activity to `android:screenOrientation="landscape"` before building.

## Important scope / honest status
This is a first playable prototype, not the finished commercial online game. It currently uses local browser/device storage. Multiplayer shared companies, competing companies, accounts, secure cloud database, real road routing, live map tiles, payment processing, GST-compliant invoicing, loans/EMI/credit score, cloud saves, and production-grade balancing are not implemented yet. Those require a backend, hosting, security rules, testing and service configuration.

## Next development milestones
1. Native Android shell, landscape lock, app icon, splash screen and APK validation.
2. Backend account system + persistent database.
3. Realtime multiplayer company world and player-vs-player competition.
4. Full India map and travel simulation with travel times/costs.
5. Quotations, GST invoice numbering/tax rules, receipts and financial reports.
6. Equipment rental/selling, maintenance, depreciation and upgrades.
7. Client contracts, staff skills, project scheduling, editing pipeline and delivery quality.
