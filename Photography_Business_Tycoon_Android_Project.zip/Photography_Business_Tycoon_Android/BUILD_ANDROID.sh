#!/usr/bin/env bash
set -euo pipefail
npm install
npm run build
if [ ! -d android ]; then npx cap add android; fi
npx cap sync android
echo "Open Android Studio with: npx cap open android"
